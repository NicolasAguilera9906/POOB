package aplicacion;

public class SorpresaPegante {
	/**
	 * Clase que ejecuta la sorpresa pegante del juego arkapoob.
	 * @author: Nicolas Aguilera y Daniel Walteros
	 * @version: 12/05/2019
	*/
}
