package presentacion;

import javax.swing.JButton;

public class MiBoton extends JButton {
	public MiBoton(String mensaje) {
		super(mensaje);
		setOpaque(false);
		this.setContentAreaFilled(false);
		this.setContentAreaFilled(false);
	}
}
